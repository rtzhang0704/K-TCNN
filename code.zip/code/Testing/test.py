import torch
from joblib import load
from sklearn.metrics import mean_absolute_error as mae
from sklearn.metrics import mean_squared_error as mse
import numpy as np
device = 'cuda' if torch.cuda.is_available() else 'cpu'

data_name = 'AEP'
kk = rf'{data_name}'
model_lin_shi = torch.load(rf'{kk}_model.pth')  
data_x_tensor_ce = load(rf'data_x_tensor_ce_{data_name}')
data_y_tensor_ce = load(rf'data_y_tensor_ce_{data_name}')
model_eval = model_lin_shi.eval()
with torch.no_grad():
    data_yu_y_ = model_eval(data_x_tensor_ce.to(device))
    data_yu_shu_pai = data_yu_y_.cpu().detach().numpy()
    data_yu_heng_pai = data_yu_shu_pai.flatten()
    data_zhen_shi_shu_pai = data_y_tensor_ce.detach().numpy()
    data_zhen_shi_heng_pai = data_zhen_shi_shu_pai.flatten()

print("MAE:", mae(data_yu_heng_pai, data_zhen_shi_heng_pai))
print("RMSE:", np.sqrt(mse(data_yu_heng_pai, data_zhen_shi_heng_pai)))
