import numpy as np
from min_max import min_max as mm
from hua_fen import hua_fen as hf
from fen import fen as f
from collections import Counter
from xiang_si_du import xiang_si_du as xsd
from sklearn.cluster import KMeans

def main(data, jiang_wei_qian_data):
    hang, lie = data.shape
    xiang_li_cha_zhi = np.zeros((hang, lie-1))
    min_xiang_li_cha_zhi = np.zeros(hang)
    lie = data.shape[1]
    for i in range(lie-1):
        xiang_li_cha_zhi[:, i] = abs(data[:, i] - data[:, i+1])
    he =xiang_li_cha_zhi.sum()
    for i in range(hang):
        for j in range(lie-1):
            if xiang_li_cha_zhi[i, j] == 0:
                xiang_li_cha_zhi[i, j] = he
    for i in range(hang):
        min_xiang_li_cha_zhi[i] = min(data[i, :])
    h_min_array, h_max_array = mm(data)
    mei_yi_ci_de_lei_shu = []
    mei_yi_ci_de_lei = []
    mei_yi_ci_de_yang_bei_fen_lei_hao = []
    pan_duan = 1
    hua_fen_ci_shu = 0
    while pan_duan:
        hua_fen_ci_shu += 1
        if hua_fen_ci_shu > 100:
            break
        hua_fen_min_array, hua_fen_max_array, cha_zhi = hf(h_min_array, h_max_array, hua_fen_ci_shu)
        zong_lei_shu, zong_lei, yang_bei_fen_lei_hao = f(data, hua_fen_min_array, hua_fen_max_array)
        mei_yi_ci_de_lei_shu.append(zong_lei_shu)
        mei_yi_ci_de_lei.append(zong_lei)
        mei_yi_ci_de_yang_bei_fen_lei_hao.append(yang_bei_fen_lei_hao)
        k = 0
        for i in range(hang):
            if min_xiang_li_cha_zhi[i] >= cha_zhi[i]:
                k += 1
        if k == hang:
            pan_duan = 0
    zong_shu = find_modes(mei_yi_ci_de_lei_shu)[0]
    zong_shu_wei_zhi = np.where(np.array(mei_yi_ci_de_lei_shu) == zong_shu)[0][0]
    zong_shu_lei = mei_yi_ci_de_lei[zong_shu_wei_zhi]
    zong_shu_yang_bei_fen_lei_hao = mei_yi_ci_de_yang_bei_fen_lei_hao[zong_shu_wei_zhi]
    zhong_xin = zhao_zhong_xin(data, zong_shu, zong_shu_lei, zong_shu_yang_bei_fen_lei_hao)
    initial_centers = np.array(zhong_xin)
    kmeans = KMeans(n_clusters=zong_shu, init=initial_centers, n_init=1,)
    results = kmeans.fit(data.T)
    labels, centers = results.labels_, results.cluster_centers_
    zhong_xin = zhao_shu_ju(data, labels, centers, jiang_wei_qian_data)
    return zhong_xin

def zhao_shu_ju(data, labels, centers, jiang_wei_qian_data):
    zhong_xin = []
    labels_chang = max(labels) + 1
    for i in range(labels_chang):
        labels_i = np.where(labels == i)[0]
        labels_i_chang = len(labels_i)
        ju_li = xsd(centers[i], data[:, labels_i[0]])
        shu_ju_wei_zhi = labels_i[0]
        for j in range(labels_i_chang):
            ju_li_j = xsd(centers[i], data[:, labels_i[j]])
            if ju_li_j <= ju_li:
                shu_ju_wei_zhi = labels_i[j]
        zhong_xin.append(jiang_wei_qian_data[:, shu_ju_wei_zhi])
    return np.array(zhong_xin).T

def zhao_zhong_xin(data, zong_shu, zong_shu_lei, zong_shu_yang_bei_fen_lei_hao):
    zhong_xin = []
    for i in range(zong_shu):
        yang_ben_ge_shu = len(zong_shu_lei[i])
        zong_ge_shu = 0
        zhong_xin_lin_shi = []
        zhong_xin_lin_shi_ping_jun = []
        for j in range(yang_ben_ge_shu):
            wei_zhi = np.where(zong_shu_yang_bei_fen_lei_hao == zong_shu_lei[i][j])[0]
            wei_zhi_ge_shu = len(wei_zhi)
            for k in range(wei_zhi_ge_shu):
                zong_ge_shu +=1
                zhong_xin_lin_shi.append(data[:, wei_zhi[k]].tolist())
        zhong_xin_lin_shi_array = np.array(zhong_xin_lin_shi)
        zhong_xin_lin_shi_array_ping_jun = zhong_xin_lin_shi_array.mean(axis=0)
        h, l = zhong_xin_lin_shi_array.shape
        xiang_si_du = []
        for j in range(h):
            sim = xsd(zhong_xin_lin_shi_array[j, :], zhong_xin_lin_shi_array_ping_jun)
            xiang_si_du.append(sim)
        zui_xiao_wei_zhi = np.where(np.array(xiang_si_du) == min(xiang_si_du))[0][0]
        zhong_xin_ping_jun_lin_shi = zhong_xin_lin_shi_array[zui_xiao_wei_zhi, :]
        zhong_xin.append(zhong_xin_ping_jun_lin_shi.tolist())
    return zhong_xin

def find_modes(lst):
    count = Counter(lst)
    return [mode for mode, freq in count.items() if freq == max(count.values())]