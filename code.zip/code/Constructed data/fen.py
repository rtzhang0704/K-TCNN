import numpy as np

def fen(data, hua_fen_min_array, hua_fen_max_array):
    h, l = data.shape
    hua_fen_ge_shu = hua_fen_min_array.shape[1]
    zuo_biao = np.ones(h, dtype=int) * hua_fen_ge_shu
    fen_ge_shu = np.zeros(zuo_biao)
    fen_zong_ge_shu = 1
    te_zheng_zuo_biao = []
    yang_bei_fen_lei_hao = np.zeros(l)
    for i in range(l):
        wei_du_zuo_biao = []
        yang_bei_fen_lei_hao_i = 0
        for j in range(h):
            for k in range(hua_fen_ge_shu):
                if (hua_fen_min_array[j, k] <= data[j, i]) and (data[j, i] < hua_fen_max_array[j, k]):
                    wei_du_zuo_biao.append(k)
                    yang_bei_fen_lei_hao_i += k * (hua_fen_ge_shu ** (h - 1 - j))
                    break
                elif (k == (hua_fen_ge_shu - 1)) and (round(data[j, i], 10) == round(hua_fen_max_array[j, k], 10)):
                    wei_du_zuo_biao.append(k)
                    yang_bei_fen_lei_hao_i += k * (hua_fen_ge_shu ** (h - 1 - j))
                    break
        fen_ge_shu[tuple(wei_du_zuo_biao)] += 1
        yang_bei_fen_lei_hao[i] = yang_bei_fen_lei_hao_i
        if i == 0:
            te_zheng_zuo_biao.append(wei_du_zuo_biao)
        if not (wei_du_zuo_biao == np.array(te_zheng_zuo_biao)).all(axis=1).any():
            te_zheng_zuo_biao.append(wei_du_zuo_biao)
            fen_zong_ge_shu += 1
    ping_jun = l / (hua_fen_ge_shu ** h)
    wei_zhi_list = []
    
    for i in range(h):
        wei_zhi_ = np.where(fen_ge_shu > ping_jun)[i].tolist()
        wei_zhi_list.append(wei_zhi_)
    
    wei_zhi_array = np.array(wei_zhi_list).T
    lie = wei_zhi_array.shape[0]
    da_yu_ping_jun_de_lei_list = []
    ju_li_array = np.zeros((lie, lie))
    for i in range(lie):
        lin_shi = 0
        for k in range(h):
            lin_shi += wei_zhi_array[i, k] * (hua_fen_ge_shu ** (h - 1 - k))
        da_yu_ping_jun_de_lei_list.append(lin_shi)
        for j in range(lie):
            ju_li_array[i, j] = ju_li(wei_zhi_array[i], wei_zhi_array[j])
    da_yu_ping_jun_de_lei_array = np.array(da_yu_ping_jun_de_lei_list)
    zong_lei = ju_lei(ju_li_array, da_yu_ping_jun_de_lei_array)
    zong_lei_shu = len(zong_lei)
    return  zong_lei_shu, zong_lei, yang_bei_fen_lei_hao

def ju_lei(ju_li_array, da_yu_ping_jun_de_lei_array):
    h = ju_li_array.shape[0]
    o_mi_ga = da_yu_ping_jun_de_lei_array.tolist()
    ga_ma = da_yu_ping_jun_de_lei_array
    zong_lei = []
    while len(o_mi_ga) > 0:
        ga_ma_old = ga_ma
        first_o_mi_ga = o_mi_ga[0]
        wei_zhi = np.where(da_yu_ping_jun_de_lei_array == first_o_mi_ga)[0][0]
        Q_wei_zhi = np.where(ju_li_array[wei_zhi, :] == 1)[0].tolist()
        Q = list(set([da_yu_ping_jun_de_lei_array[i] for i in Q_wei_zhi]) | set([first_o_mi_ga]))
        ga_ma = list(set(ga_ma) - set(Q))
        pan_duan = Q.copy()
        while len(Q) > 0:
            first_Q = Q.pop(0)
            wei_zhi_Q = np.where(da_yu_ping_jun_de_lei_array == first_Q)[0][0]
            de_er_ta_wei_zhi = np.where(ju_li_array[wei_zhi_Q, :] == 1)[0].tolist()
            Q_wei_zhi_lin_shi = [da_yu_ping_jun_de_lei_array[i] for i in de_er_ta_wei_zhi]
            if not all([i in pan_duan for i in Q_wei_zhi_lin_shi]):
                pan_duan = list(set(pan_duan) | set(Q_wei_zhi_lin_shi))
                Q = list(set(Q) | set(Q_wei_zhi_lin_shi))
            ga_ma = list(set(ga_ma) - set(Q))
        lei = list(set(ga_ma_old) - set(ga_ma))
        o_mi_ga = list(set(o_mi_ga) - set(lei))
        zong_lei.append(lei)
    return zong_lei

def ju_li(seq1, seq2):
    chang = len(seq1)
    ge_shu = 0
    shu_chu = 1
    for i in range(chang):
        if seq1[i] != seq2[i]:
            cha_zhi = abs(seq1[i] - seq2[i])
            ge_shu += 1
    if ge_shu >=2 or ge_shu == 0 or cha_zhi !=1:
        shu_chu = 0
    return shu_chu
