import numpy as np

def min_max(data):
    h = data.shape[0]
    h_max_list = []
    h_min_list = []
    for i in range(h):
        h_max = data[i, :].max()
        h_min = data[i, :].min()
        h_max_list.append(h_max)
        h_min_list.append(h_min)
    return np.array(h_min_list), np.array(h_max_list)
