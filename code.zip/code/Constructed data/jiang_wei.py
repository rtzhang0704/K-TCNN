from sklearn.manifold import MDS

def jiang_wei(data, wei_du_jiang_wei_hou, random_state=42):
    mds = MDS(n_components=wei_du_jiang_wei_hou, random_state=random_state)
    X_mds = mds.fit_transform(data)
    return X_mds