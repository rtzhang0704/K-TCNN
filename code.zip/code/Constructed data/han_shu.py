import numpy as np
def han_shu(seq):
    k_list = []
    b_list = []
    xia_list = []
    shang_list = []
    for i in range(len(seq)-1):
        k = (seq[i+1] - seq[i])
        k_list.append(k)
        b = seq[i] - k * (i+1)
        b_list.append(b)
        xia_list.append(i+1)
        shang_list.append(i+2)
    k_array = np.array(k_list)
    b_array = np.array(b_list)
    return k_array, b_array
