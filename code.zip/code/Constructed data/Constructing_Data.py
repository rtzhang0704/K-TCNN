from du_qu_data import du_qu_data as dqd
import torch
from torch.utils.data import TensorDataset, DataLoader
from joblib import dump

import numpy as np
seed = 42
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)
np.random.seed(seed)

data_name = 'ALE'
kk = rf'{data_name}'
path = rf'.\{data_name}.xlsx'
data_ = dqd(path)
data = torch.tensor(data_)
n_h, n_l = data.shape
num_ce = int(0.8*n_h)
data_x, data_y = data[:, :-1], data[:, -1]

data_x_tensor = torch.Tensor(data_x)
data_y_tensor = torch.Tensor(data_y)
data_x_tensor_xun = data_x_tensor[:num_ce]
data_x_tensor_ce = data_x_tensor[num_ce:]
data_y_tensor_xun = data_y_tensor[:num_ce]
data_y_tensor_ce = data_y_tensor[num_ce:]

data_loader = DataLoader(
            TensorDataset(
                data_x_tensor_xun, data_y_tensor_xun
            ), batch_size=32, shuffle=True, drop_last=False
        )
dump(data_loader, f'dataloader_{kk}')
dump(data_x_tensor_ce, f'data_x_tensor_ce_{kk}')
dump(data_y_tensor_ce, f'data_y_tensor_ce_{kk}')