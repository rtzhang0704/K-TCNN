import numpy as np

def hua_fen(h_min, h_max, N_D):
    h = h_min.shape[0]
    diff = h_max - h_min
    cha_zhi = diff / (N_D + 1)
    hua_fen_min_list = []
    hua_fen_max_list = []
    for i in range(h):
        hua_fen_min = []
        hua_fen_max = []
        for j in range(N_D+1):
            min_ = h_min[i] + (j / (N_D + 1)) * diff[i]
            max_ = h_min[i] + ((j + 1) / (N_D + 1)) * diff[i]
            hua_fen_min.append(min_)
            hua_fen_max.append(max_)
        hua_fen_min_list.append(hua_fen_min)
        hua_fen_max_list.append(hua_fen_max)
    return np.array(hua_fen_min_list), np.array(hua_fen_max_list), cha_zhi
