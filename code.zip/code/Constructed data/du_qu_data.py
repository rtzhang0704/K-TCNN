# 读取数据
import numpy as np
import pandas as pd
from jiang_wei import jiang_wei as jw
from sklearn.preprocessing import MinMaxScaler
from main import main

import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
def du_qu_data(path):
    s = MinMaxScaler()
    data_read = pd.read_excel(path, header=None)
    data_values = data_read.values.astype(np.float32)
    data_x = data_values[:, :-1]
    data_y = data_values[:, -1]
    data_x_jiang_wei_hou = jw(data_x.T, 2)
    data_x_jiang_wei_hou_T = data_x_jiang_wei_hou.T
    data_xuan_zhe_hou = main(data_x_jiang_wei_hou_T, data_x)
    data_xuan_zhe_hou_ = np.hstack([data_xuan_zhe_hou, data_y.reshape(len(data_y), 1)])
    data_x_jiang_wei_hou_T_gui = s.fit_transform(data_xuan_zhe_hou_)
    return data_x_jiang_wei_hou_T_gui
