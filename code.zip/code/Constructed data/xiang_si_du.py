import numpy as np
from mian_ji import mian_ji as mj
def mianji(seq_xia, seq_shang, x):
    S = []
    for i in x:
        seq_xin = seq_xia + i
        s = mj(seq_xin, seq_shang)
        S.append(s)
    S_array = np.array(S)
    S_min = S_array.min()
    L_min = x[np.where(S_array == S_min)][0]
    return L_min, S_min

def xiang_si_du(seq1, seq2):
    if seq1.max() <= seq2.min():
        seq_max = (abs(seq1 - seq2)).max()
        seq_min = (abs(seq1 - seq2)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min, S_min = mianji(seq1, seq2, x)
        sim = L_min + np.sqrt(S_min)
    elif seq1.min() >= seq2.max():
        seq_max = (abs(seq1 - seq2)).max()
        seq_min = (abs(seq1 - seq2)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min, S_min = mianji(seq2, seq1, x)
        sim = L_min + np.sqrt(S_min)
    elif seq1.max() >= seq2.max() and seq1.min() <= seq2.min():
        seq_max_y = (abs(seq1 - seq2)).max()
        seq2_xin = seq2 - seq_max_y
        seq_max = (abs(seq1 - seq2_xin)).max()
        seq_min = (abs(seq1 - seq2_xin)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min_y, S_min = mianji(seq2, seq1, x)
        L_min = abs(L_min_y - seq_max_y)
        sim = L_min + np.sqrt(S_min)
    elif seq2.max() >= seq1.max() and seq2.min() <= seq1.min():
        seq_max_y = (abs(seq1 - seq2)).max()
        seq1_xin = seq1 - seq_max_y
        seq_max = (abs(seq2 - seq1_xin)).max()
        seq_min = (abs(seq2 - seq1_xin)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min_y, S_min = mianji(seq1, seq2, x)
        L_min = abs(L_min_y - seq_max_y)
        sim = L_min + np.sqrt(S_min)
    elif seq1.min() <= seq2.min() and seq2.min() <= seq1.max() and seq1.max() <= seq2.max():
        seq_max_y = (abs(seq1 - seq2)).max()
        seq1_xin = seq1 - seq_max_y
        seq_max = (abs(seq2 - seq1_xin)).max()
        seq_min = (abs(seq2 - seq1_xin)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min_y, S_min = mianji(seq1, seq2, x)
        L_min = abs(L_min_y - seq_max_y)
        sim = L_min + np.sqrt(S_min)
    else:
        seq_max_y = (abs(seq1 - seq2)).max()
        seq2_xin = seq2 - seq_max_y
        seq_max = (abs(seq1 - seq2_xin)).max()
        seq_min = (abs(seq1 - seq2_xin)).min()
        x = np.linspace(seq_min, seq_max, 100)
        L_min_y, S_min = mianji(seq2, seq1, x)
        L_min = abs(L_min_y - seq_max_y)
        sim = L_min + np.sqrt(S_min)
    return sim
