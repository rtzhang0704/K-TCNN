import numpy as np
def fan_wei(seq):
    xia_list = []
    shang_list = []
    for i in range(len(seq)-1):
        xia_list.append(i+1)
        shang_list.append(i+2)
    xia_arraay = np.array(xia_list)
    shang_arraay = np.array(shang_list)
    return np.array(xia_arraay), np.array(shang_arraay)
