from scipy.integrate import quad
from fan_wei import fan_wei as fw
from han_shu import han_shu as hs

def mian_ji(seq1, seq2):
    k_1, b_1= hs(seq1)
    k_2, b_2= hs(seq2)
    xia, shang = fw(seq1)
    mian_ji = 0
    for i in range(len(k_1)):
        f = lambda x: k_1[i] * x + b_1[i]
        g = lambda x: k_2[i] * x + b_2[i]
        result, _ = quad(lambda x: abs(f(x) - g(x)), xia[i], shang[i])
        mian_ji += result
    return mian_ji
