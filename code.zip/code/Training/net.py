import torch
import torch.nn as nn
from torch.nn import Transformer, TransformerEncoder, TransformerEncoderLayer

class Transformer(nn.Module):
    def __init__(self, import_size, input_dim, hidden_dim, output_dim, num_layers, num_heads):
        super().__init__()
        self.transformer = TransformerEncoder(
            TransformerEncoderLayer(
                input_dim, num_heads, hidden_dim, dropout=0.2, batch_first=True
            ),
            num_layers
        )
        self.linear_fea  = nn.Linear(import_size, 64)
        self.linear_seq  = nn.Linear(input_dim, output_dim)
    def forward(self, input_seq):
        transformer_output = self.transformer(input_seq)  
        output_avgpool_fea = transformer_output.permute(0, 2, 1)  
        predict_fea = self.linear_fea(output_avgpool_fea) 
        output_avgpool_seq = predict_fea.permute(0, 2, 1)
        predict_seq = self.linear_seq(output_avgpool_seq)
        return predict_seq

class LinearL(nn.Module):
    def __init__(self, in_fea, out_fea, input_dim, output_dim):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(
                in_features=input_dim, out_features=output_dim
            ), nn.Dropout(0.2)
        )
        self.linear_fea  = nn.Linear(in_fea, out_fea)
    def forward(self, input_seq):
        output = self.fc(input_seq) 
        output_avgpool_fea = output.permute(0, 2, 1)  
        predict_fea = self.linear_fea(output_avgpool_fea)   
        output_avgpool_seq = predict_fea.permute(0, 2, 1)
        return output_avgpool_seq
class net(nn.Module):
    def __init__(self, import_size, seq_len=128,
                kernel_size_C1=3, kernel_size_C2=3,
                kernel_size_M1=2, kernel_size_M2=2,
                stride_C1=1, stride_C2=1, stride_M1=2, stride_M2=2,
                hidden_dim_T_1=64, num_layers_T_1=2, num_heads_T_1=8,
                hidden_dim_T_2=64, num_layers_T_2=2, num_heads_T_2=8,
                output_L_3=1):
        super(net, self).__init__()
        self.em = nn.Linear(1, seq_len)
        self.max1 = nn.MaxPool1d(kernel_size=kernel_size_M1, stride=stride_M1)
        self.max2 = nn.MaxPool1d(kernel_size=kernel_size_M2, stride=stride_M2)
        self.r = nn.ReLU()
        self.cnn1 = nn.Sequential(
            nn.Conv1d(  
                in_channels=import_size, out_channels=64,
                kernel_size=kernel_size_C1, stride=stride_C1, padding=kernel_size_C1//2
            ), self.max1, nn.Dropout(0.2)
        )
        self.cnn2 = nn.Sequential(
            nn.Conv1d(
                in_channels=64, out_channels=64,
                kernel_size=kernel_size_C2, stride=stride_C2, padding=kernel_size_C2//2
                ), self.max2, nn.Dropout(0.2)
        )
        self.fc1 = LinearL(
            in_fea=import_size, out_fea=64,
            input_dim=seq_len, output_dim=seq_len//2
        )
        self.fc2 = LinearL(
            in_fea=64, out_fea=64,
            input_dim=seq_len//2, output_dim=seq_len//4
        )
        self.fc3 = nn.Sequential(
            nn.Linear(
                in_features=(seq_len//2)*(seq_len//4), out_features=output_L_3
            ), nn.Dropout(0.2)
        )
        self.t1 = Transformer(
            import_size=import_size, input_dim=seq_len, output_dim=seq_len//2,
            hidden_dim=hidden_dim_T_1, num_layers=num_layers_T_1,
            num_heads=num_heads_T_1
        )
        self.t2 = Transformer(
            import_size=64, input_dim=seq_len//2, output_dim=seq_len//4,
            hidden_dim=hidden_dim_T_2, num_layers=num_layers_T_2,
            num_heads=num_heads_T_2
        )
    def forward(self, x):
        x = x.unsqueeze(-1)
        x = self.em(x)
        y_C_1 = self.cnn1(x)
        y_T_1 = self.t1(x)
        y_L_1 = self.fc1(x)
        x_C_ = y_C_1 + y_T_1 + y_L_1
        x_C_2 = self.r(x_C_)
        x_T_ = y_T_1 + y_C_1
        x_T_2 = self.r(x_T_)
        x_L_ = y_L_1 + y_C_1
        x_L_2 = self.r(x_L_)
        y_C_2 = self.cnn2(x_C_2)
        y_T_2 = self.t2(x_T_2)
        y_L_2 = self.fc2(x_L_2)
        x_L_3_ = y_C_2 + y_T_2 +y_L_2
        x_L_3 = self.r(x_L_3_)
        x_L_3 = x_L_3.view(x_L_3.size(0), -1)
        y = self.fc3(x_L_3)
        return y
