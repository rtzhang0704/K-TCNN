import torch
from net import net
from torch import nn
from torch.optim import Adam
from tqdm import tqdm
from joblib import load
import time
from sklearn.metrics import mean_absolute_error as mae
from sklearn.metrics import mean_squared_error as mse
import numpy as np
device = 'cuda' if torch.cuda.is_available() else 'cpu'

epochs = 1000
data_name = 'AEP'
kk = rf'{data_name}'
data_loader = load(f'dataloader_{kk}')
data_x_tensor_ce = load(f'data_x_tensor_ce_{kk}')
data_y_tensor_ce = load(f'data_y_tensor_ce_{kk}')
n_h, n_l = data_x_tensor_ce.shape
n_l += 1
model_ = net(import_size=n_l-1, output_L_3=1)
model = model_.to(device)
loss_fn = nn.MSELoss()
optimizer = Adam(model.parameters(), lr=1e-2)
start_time = time.time()
for i in tqdm(range(epochs)):
    model.train()
    for id, (x, y) in enumerate(data_loader):
        x = x.to(device)
        y = y.to(device)
        prediction = model(x)
        batch_loss = loss_fn(prediction.flatten(), y)
        batch_loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    print('Epoch:', '%04d' % (i + 1), 'cost =', '{:.6f}'.format(batch_loss))

torch.save(model, rf'{kk}_model.pth')
print(time.time() - start_time)

model_lin_shi = torch.load(rf'{kk}_model.pth')  
model_eval = model_lin_shi.eval()
with torch.no_grad():
    data_yu_y_ = model_eval(data_x_tensor_ce)
    data_yu_shu_pai = data_yu_y_.cpu().detach().numpy()
    data_yu_heng_pai = data_yu_shu_pai.flatten()
    data_zhen_shi_shu_pai = data_y_tensor_ce.detach().numpy()
    data_zhen_shi_heng_pai = data_zhen_shi_shu_pai.flatten()
print("MAE:", mae(data_yu_heng_pai, data_zhen_shi_heng_pai))
print("RMSE:", np.sqrt(mse(data_yu_heng_pai, data_zhen_shi_heng_pai)))
